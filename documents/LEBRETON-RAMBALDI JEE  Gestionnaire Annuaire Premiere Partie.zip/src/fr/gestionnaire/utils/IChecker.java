package fr.gestionnaire.utils;

public interface IChecker {
	
	public boolean validate(final String string);
}
